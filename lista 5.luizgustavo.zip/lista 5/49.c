#include<stdio.h>
#include<string.h>

void recursivo(){
	int a;
	printf("digite o num\n");
	scanf("%d",&a);
	if(a<0)
		return;
	else
		printf("%d\n",a);
		recursivo();
}
int main(){
	recursivo();
}