#include<stdio.h>

int iterativa (int n){
	int x=1, i;
	for(i=1;i<=n;i++)
		x*=i;
	return x;
}
int recursiva(int n){
	if(n==1)
	return 1;
	else
	return n*recursiva(n-1);
}
int main(){
	int fat, a,b=0,fat2;
	scanf("%d",&a);
	fat =iterativa(a);
	fat2=recursiva(a);
	printf("iterativa: %d, recursiva: %d",fat,fat2);
}