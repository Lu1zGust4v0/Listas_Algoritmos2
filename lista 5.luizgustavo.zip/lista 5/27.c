#include<stdio.h>

int b(int num){
	return 10*num;
}
int s(int num){
	int a=1,b=2;
	while(b<=num){
		a+=b*b;
		b++;
	}
	return a;
}
int main(){
	int num;
	printf("qual termo vc quer saber das sequencias?");
	scanf("%d",&num);
	printf("\n%d da s e %d da b",b(num),s(num));
	
}