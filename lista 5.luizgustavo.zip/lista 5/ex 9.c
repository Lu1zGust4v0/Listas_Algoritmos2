#include<stdio.h>


int recursiva(int n, int m){
	int mult;
	if(m==0)	
		return 1;
	return n*(recursiva(n,m-1));
}

int main(){
	int fat, a=0,b=0, m1,m2;
	while(a==0){
		
	printf("digite os 2 numeros, o primeiro elevado ao segundo");
	scanf("%d %d",&m1,&m2);
	
	printf("recursiva: %d, 0 para continuar",recursiva(m1,m2));
	scanf("%d",&a);
}
}