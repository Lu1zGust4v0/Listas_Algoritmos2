#include<stdio.h>
#include<string.h>

int f91(int n){
	if(n>100)
		return n-10;
	else
		return f91(f91(n+11));
}

int main(){
	int num;
	printf("digite o numero:");
	scanf("%d",&num);
	
	printf("%d",f91(num));
}