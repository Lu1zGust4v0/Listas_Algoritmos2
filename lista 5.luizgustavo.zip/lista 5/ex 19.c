#include<stdio.h>

void soma(int v1[], int v2[], int v3[], int inicio, int fim){
	if (inicio>fim) {
        return;
    }
    if (inicio==fim) {
        v3[inicio] = v1[inicio] + v2[inicio];
        return;
    }

    int meio=(inicio + fim)/2;
    soma(v1, v2, v3,inicio,meio);
    soma(v1,v2,v3,meio+1,fim);
}

int main(){
	int num,v1[200],v2[200],i,v3[200];
	printf("qual o tamanho?\n");
	scanf("%d",&num);
	printf("os elementos do primeiros\n");
	for(i=0;i<num;i++){
		scanf("%d",&v1[i]);
	}
	printf("o segundo\n");
	for(i=0;i<num;i++){
		scanf("%d",&v2[i]);
	}
	soma(v1,v2,v3,0,num-1);
	
	for(i=0;i<num;i++)
		printf("%d ",v3[i]);
	
}