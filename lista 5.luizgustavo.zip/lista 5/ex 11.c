#include<stdio.h>
#include<string.h>
void inverte(char s[], int num, int a){
	char aux;
	if (num >=(a-num))
        return;
	
	aux = s[num];
	s[num]=s[a-num];
 	s[a-num]=aux;
 	
	inverte(s,num+1,a);
	
}

int main(){
	char s[1000], a=0;
	printf("digite a sequencia:");
	scanf("%s",s);
	inverte(s,0,strlen(s)-1);
	printf("%s",s);
}