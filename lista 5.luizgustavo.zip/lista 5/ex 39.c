#include<stdio.h>
#include<string.h>

void par(int n, int m){
	int i;
	if(m<0){
		return;
	}
	else if((n-m)%2==0){
		printf("%d ",n-m);
	}
	par(n,m-1);
}
int main(){
	int n;
	printf("qual o n?");
	scanf("%d",&n);
	
	par(n,n);
}