#include<stdio.h>
#include<string.h>

int quad(int num){
	if(num==0)
	return 0;
	return num*num+quad(num-1);
}

int main(){
	int num;
	printf("digite o numero:");
	scanf("%d",&num);
	
	printf("%d",quad(num));
	
	
}