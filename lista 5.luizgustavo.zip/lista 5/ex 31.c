#include<stdio.h>
#include<string.h>

void troca(char *x, char *y){
	char temp=*x;
	*x=*y;
	*y=temp;
}

void perm(char str[], int num,int b){
	int i;
	char aux, aux1;
	
	if(num==b)
		printf("%s ",str);
	
	else{
		for(i=num;i<=b;i++){
			troca(&str[num],&str[i]);
			perm(str,num+1,b);
			troca(&str[num],&str[i]);		
	}
	
}
}

int main(){
	char str[]="123";
	int b;

	b=strlen(str);
	perm(str,0,b-1);
}