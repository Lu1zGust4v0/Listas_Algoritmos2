#include <stdio.h>

int busca(int *v, int i, int a, int b){
	printf("Oi");
	int meio = (i+a)/2;
	if(v[meio]==b)
	return meio;
	else if(b>v[meio])
		return busca(v,meio+1,a,b);
	else if(b<v[meio])
	return busca(v,i,meio-1,b);
	
}

int main(){
	int v[]={2,3,7,9,10,11,12,19,20,21,23,24,34,54,76,78}, num=34, tam=16;
	printf("%d", busca(v,0, tam-1,num));
	
	
}