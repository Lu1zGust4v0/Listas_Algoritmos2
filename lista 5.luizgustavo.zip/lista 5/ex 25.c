#include<stdio.h>
#include<string.h>
int um (char bin[], int num){
	int a;
	if(bin[num]=='1'&&bin[num+1]=='1')
		return num;
	if(num==strlen(bin))
		return strlen(bin);	
	um(bin,num+1);
}

int main(){
	int i,num=0,num1;
	char bin[300];
	printf("digite seu binario:");
	scanf("%s",bin);
	num1 =um(bin, num);
	
	for(i=0;i<num1;i++)
	printf("%c",bin[i]);
	printf(" %d numeros",num1);
}