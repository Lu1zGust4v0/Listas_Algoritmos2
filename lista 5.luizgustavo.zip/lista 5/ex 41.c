#include<stdio.h>
#include<string.h>

void conjunto(char a[], int b, int c, int d){
	if(c==b)
		return;

	printf("(%c,%c)\n",a[c],a[d]);
	
	 if(d==b){
		conjunto(a,b,c+1,c+2);
	}
	else
		conjunto(a,b,c,d+1);
	
}

int main(){
	int i, num;
	char a[1000];
	printf("digite o conjunto? No modelo: 'abcd'");
	scanf("%s",a);
	i=strlen(a);	
	conjunto(a,i-1,0,1);
}