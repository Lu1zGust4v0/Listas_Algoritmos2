#include<stdio.h>

int soma(int n){
	int s=0;
	for(int i=0;i<=n;i++)
		s+=i;
		return s;
}

int main(){
	int n;
	printf("qual seu n?");
	scanf("%d",&n);
	printf("\n%d",soma(n));
}