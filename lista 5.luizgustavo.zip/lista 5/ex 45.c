#include<stdio.h>
#include<string.h>

float s(int n, int a){
	if(a>(n+1))
		return 0;
	int i;
	float num=1;
	for(i=1;i<a;i++)
		num*=i;
	return 1/num + s(n,a+1);
	
}
int main(){
	int n;
	printf("digite o n:");
	scanf("%d",&n);
	printf("\ns:%.2f",s(n,1));
}