#include<stdio.h>
#include<string.h>
	
	int soma(int j, int i){
		if(j>i)
			return 0;
		else
		return j+soma(j+1,i);
	}
int main(){
	int a, b;
	printf("quais os numeros que vc quer somar entre eles?\n");
	scanf("%d %d",&a,&b);
	printf("soma:%d\n",soma(a,b));
}