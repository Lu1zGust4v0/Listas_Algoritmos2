#include<stdio.h>


int recursiva(int n, int m){
	int mult;
	if(m==0)	
		return 0;
	return n+(recursiva(n,m-1));
}

int iterativa(int n, int m){
	int a=0, mult=0;
	while(a<m){
		mult+=n;
		a++;
}
return mult;	
}
int main(){
	int fat, a,b=0, m1,m2;
	printf("digite os 2 numeros");
	scanf("%d %d",&m1,&m2);


	printf("recursiva: %d e iterativa %d",recursiva(m1,m2),iterativa(m1,m2));
}