#include<stdio.h>
#include<string.h>
int palin(char str[],int a, int b){
	int i;
	if(a>=b)
		return 1;
	
	if(str[a]==str[b])
		return palin(str,a+1,b-1);
	else 
		return 0;
}

int main(){
	int a,c;
	char str[]="123321";
	c = strlen(str);
	a =palin(str,0,c-1);
	if(a==1)
		printf("eh palindromo");
	else
		printf("Nao eh palindromo");
	
}
