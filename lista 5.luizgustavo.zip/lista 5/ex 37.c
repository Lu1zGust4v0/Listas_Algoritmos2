#include<stdio.h>
#include<string.h>

int validez(char str[], int e){
	if(e==strlen(str))
		return 1;
	
	if((str[e]>47 && str[e]<58)||(str[e]>64&&str[e]<91)||(str[e]>96&&str[e]<123))
		return validez(str,e+1);
	else
		return 0;
		
}

int main(){
	int a;
	char str[1000];
	printf("digite a cadeia:");
	scanf("%s",str);
	
	a=validez(str,0);
	if(a==0)
		printf("expressao invalida\n");
	else
		printf("expressao valida");
}