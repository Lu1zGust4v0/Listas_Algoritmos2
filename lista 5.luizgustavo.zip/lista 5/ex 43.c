#include<stdio.h>
#include<string.h>

int soma(int v[], int num, int aux){
	if(num==aux)
		return 0;
	else
	return v[num]+soma(v,num+1,aux);
}

int produto(int v[],int aux, int num){
	if(num==aux)
		return 1;
	else
		return v[aux]*produto(v,aux+1,num);
}

int main(){
	int v[1000],num,i;
	printf("quntos elementos tem o vetor?\n");
	scanf("%d",&num);
	printf("DIGITE-OS\n");
	for(i=0;i<num;i++)
		scanf("%d",&v[i]);
	printf("\nsoma:%d e produto %d",soma(v,0,num),produto(v,0,num));
}