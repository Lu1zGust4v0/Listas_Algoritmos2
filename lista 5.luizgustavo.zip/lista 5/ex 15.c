#include<stdio.h>
#include<string.h>

int max(int x, int y){
	if(y<=x && x%y==0)
	return y;
	else if(x<y){
		max(y,x);
	}
	else
	return max(y,x%y);
}

int main(){
	int num,a;
	printf("digite os 2 numeros para descobir mdc:");
	scanf("%d %d",&num,&a);
	
	printf("%d",max(num,a));
	
	
}