#include<stdio.h>
#include <stdlib.h>
int main(){
	int i,a=0;
	float b=0, d=0;
	char texto[3000],*c;
	FILE*arquivo1, *arquivo2;
	if((arquivo1=fopen("texto.txt","r"))==NULL){
		printf("erro1");
		return 0;
	}
	
	while((fgets(texto,3000,arquivo1))!=NULL)
	{
	
	c = strtok(texto, ":;\n");
	while(c!=NULL){
		
		printf("%s;",c);
		b=atof(c);
		if(a==1||a==2)
			d+=b;
		c = strtok(NULL, ":;\n");
		a++;
		
}
	if(d/2>=5){
	
		printf("%.2f aprovado\n",d/2);
	
	}
	else if(d/2<5){
	
		printf("%.2f reprovado\n",d/2);
		
	}}
}
		
