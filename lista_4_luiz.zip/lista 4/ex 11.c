#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int cont(char *mchar, char *caractere) {
    int i;
    int count = 0;
    int text_len = strlen(caractere);
    int word_len = strlen(mchar);
    
    for (i = 0; i <= text_len - word_len; i++) {
        if (strncmp(&caractere[i], mchar, word_len) == 0) {
			 if ((i == 0 || caractere[i - 1] == ' ' || caractere[i - 1] == '.' || caractere[i - 1] == ',' || caractere[i - 1] == '\n') &&
                (caractere[i + word_len] == ' ' || caractere[i + word_len] == '.' || caractere[i + word_len] == ',' || caractere[i + word_len] == '\n' || caractere[i + word_len] == '\0')) {
                count++;
            }
        }
    }
    return count;
}

int main() {
    int i, num;
    char nome1[200], caractere[800], original[800], mchar[20];
    
    printf("Nome do arquivo das matrizes: ");
    scanf("%199s", nome1); 
    FILE *arquivo = fopen(nome1, "r");
    if (arquivo == NULL) {
        perror("Erro ao abrir o arquivo");
        return EXIT_FAILURE;
    }

    i = 0;
    while ((caractere[i] = getc(arquivo)) != EOF) {
        i++;
    }
    caractere[i] = '\0';
    fclose(arquivo);
    strcpy(original, caractere);

    char *token = strtok(caractere, " .,\n");
    while (token != NULL) {
        strcpy(mchar, token);
        printf("A palavra \"%s\" aparece ", mchar);
        num = cont(mchar, original);  
        
        printf("%d vez(es)\n", num);
        token = strtok(NULL, " .,\n");
    }

    return 0;
}
