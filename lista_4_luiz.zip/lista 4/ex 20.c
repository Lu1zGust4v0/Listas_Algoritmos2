#include<stdio.h>
#include<string.h>

int main() {
    int i = 0, j = 0, k;
    char nome1[200], nome2[100], vet[2000], str1[3000], str2[3000];
    printf("Nome do primeiro arquivo: ");
    gets(nome1);
    printf("Nome do segundo arquivo: ");
    gets(nome2);
    FILE *arquivo1, *arquivo2, *arquivo3;
    if ((arquivo1 = fopen(nome1, "r")) == NULL) {
        printf("Erro ao abrir o primeiro arquivo.");
        return 0;
    }

    if ((arquivo2 = fopen(nome2, "r")) == NULL) {
        printf("Erro ao abrir o segundo arquivo.");
        fclose(arquivo1);
        return 0;
    }

    

    while ((str1[i++] = getc(arquivo1)) != EOF) 
    str1[i]='\0';
      while ((str2[j++] = getc(arquivo2)) != EOF)
    str2[i]='\0';
    
    for(i=0;i<j;i++){
    	if(str1[i]==str2[i])
    		printf("%c - %d\n",str1[i], i);
	}
    fclose(arquivo1);
    fclose(arquivo2);



    return 0;
}
