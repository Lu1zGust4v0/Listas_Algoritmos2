#include<stdio.h>

int main(){
	char caractere;
	FILE*arquivo1;
	FILE*arquivo2;
	if((arquivo1 = fopen("matriz.txt","r"))==NULL){
		printf("erro1");
		exit(1);
	}
	if((arquivo2 = fopen("ex9.txt","w"))==NULL){
		printf("erro");
		exit(1);
	}
	while((caractere=getc(arquivo1))!=EOF){
		putc(caractere, arquivo2);
	}
	fclose(arquivo1);
	fclose(arquivo2);
}