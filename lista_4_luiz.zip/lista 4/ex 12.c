#include<stdio.h>

int main(){
	int i,a=0;
	char texto[3000],*c;
	FILE*arquivo1, *arquivo2;
	if((arquivo1=fopen("texto.txt","r"))==NULL){
		printf("erro1");
		return 0;
	}
	if((arquivo2=fopen("vogais.txt","w"))==NULL){
		printf("erro");
		return 0;
	}
	while((fgets(texto,3000,arquivo1))!=NULL)
		printf("%s",texto);
	
	c = strtok(texto, " .,-");
	while(c!=NULL){
			if(c[0]=='A'||c[0]=='a'||c[0]=='E'||c[0]=='e'||c[0]=='I'||c[0]=='i'||c[0]=='O'||c[0]=='o'||c[0]=='U'||c[0]=='u'){
				a++;
				fprintf(arquivo2,"%s ",c);
			}
			c = strtok(NULL, " .,-");
		
	}
	printf("\n%d palavras",a);
}