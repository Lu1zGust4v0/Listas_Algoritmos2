#include <stdio.h>
#include <string.h>

int main() {
    char nome[100], caracter;
    printf("qual nome?\n");
    gets(nome);
    FILE *arquivo = fopen(nome, "r");
    if (arquivo == NULL) {
        perror("Não foi possível abrir o arquivo para escrita");
        return 1;
}
    while ((caracter = getc(arquivo)) != EOF) {
    	if(caracter>64 && caracter<91)
        putchar(caracter-32);
        else
        putchar(caracter);
    }
    fclose(arquivo);

    return 0;
}
