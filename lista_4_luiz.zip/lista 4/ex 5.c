#include<stdio.h>
#include<string.h>
int main(){
	int cont=0;
	char pala[100], nome[100], nome2[100], caractere[3000], *teste;
	printf("qual o nome do primeiro arq?");
	scanf("%s",nome);
	getchar();
	printf("\ne a palavra?");
	gets(pala);
	fflush(stdin);
	FILE*arquivo;
	if((arquivo = fopen(nome,"r"))==NULL){
		printf("erro");
		exit(1);
	}
	int i=0;
	while((caractere[i]=getc(arquivo))!= EOF){
		i++;
	}
	caractere[i] = '\0';
	teste=strtok(caractere, " .,\n");
		while(teste!=NULL){
			if((strcmp(teste, pala))==0)
				cont++;
		teste=strtok(NULL, " .,\n");
		}
	
	printf("apareceu %d vezes", cont);
	fclose(arquivo);
}