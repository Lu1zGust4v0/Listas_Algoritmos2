#include<stdio.h>
#include<string.h>
int main(){
	char nome[100], caracter;
	printf("qual nome vc quer para o arquivo?\n");
	gets(nome);
	 FILE *arquivo = fopen(nome, "w");
        if (arquivo == NULL) {
            perror("Não foi possível abrir o arquivo para escrita");
            return 1;
        }
	fprintf(arquivo, "Este eh um arquivo texto");
	fclose(arquivo);
	arquivo = fopen(nome, "r");
        if (arquivo == NULL) {
            perror("Não foi possível abrir o arquivo para leitura");
            return 1;
        }
	while ((caracter = getc(arquivo))!=EOF) {
	 putchar(caracter);
};
}