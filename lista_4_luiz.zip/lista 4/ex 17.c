#include<stdio.h>
#include<string.h>

int main() {
    int i = 0, j = 0, k;
    char nome1[200], nome2[100], vet[2000], str[140];
    printf("Nome do primeiro arquivo: ");
    gets(nome1);
    printf("Nome do segundo arquivo: ");
    gets(nome2);
    FILE *arquivo1, *arquivo2, *arquivo3;
    if ((arquivo1 = fopen(nome1, "r")) == NULL) {
        printf("Erro ao abrir o primeiro arquivo.");
        return 0;
    }

    if ((arquivo2 = fopen(nome2, "r")) == NULL) {
        printf("Erro ao abrir o segundo arquivo.");
        fclose(arquivo1);
        return 0;
    }

    if ((arquivo3 = fopen("vetor.txt", "w")) == NULL) {
        printf("Erro ao abrir o arquivo de saída.");
        fclose(arquivo1);
        fclose(arquivo2);
        return 0;
    }

    while ((vet[i] = getc(arquivo1)) != EOF) {
        if ((vet[i] >= '0' && vet[i] <= '9') || vet[i] == ' ') {
            str[j++] = vet[i];
        }
        i++;
    }
    i = 0;
    while ((vet[i] = getc(arquivo2)) != EOF) {
        if ((vet[i] >= '0' && vet[i] <= '9') || vet[i] == ' ') {
            str[j++] = vet[i];
        }
        i++;
    }
    char aux;
    for (int i = 0; i < j; i++) {
        for (int k = i + 1; k < j; k++) {
            if (str[i] > str[k] && str[i]!=' '&& str[k]!=' ') {
                aux = str[i];
                str[i] = str[k];
                str[k] = aux;
       }
    }
    }

    for (int i = 0; i < j; i++) {
        putc(str[i], arquivo3);
    }

    fclose(arquivo1);
    fclose(arquivo2);
    fclose(arquivo3);


    return 0;
}
