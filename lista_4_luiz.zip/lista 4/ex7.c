#include<stdio.h>

int main(){
	char nome[100], nome2[100], caractere;
	printf("qual o nome do primeiro arq?");
	scanf("%s",nome);
	fflush(stdin);
	printf("\ne do segundo?");
	gets(nome2);

	FILE*arquivo;
	FILE*arquivo2;
	FILE*arquivo3;
	
	if((arquivo = fopen(nome, "r"))==NULL){
		printf("erro1");
		exit(1);
	}
	if((arquivo3 = fopen("teste.txt", "w"))==NULL){
		printf("erro");
		exit(1);
	}
	while((caractere = getc(arquivo))!=EOF){
		putc(caractere,arquivo3);
	}
	if((arquivo2 = fopen(nome2, "r"))==NULL){
		printf("erro2");
		exit(1);
	}
	while((caractere = getc(arquivo2))!=EOF){
		putc(caractere,arquivo3);
	}
	fclose(arquivo);
	fclose(arquivo2);
	fclose(arquivo3);
}