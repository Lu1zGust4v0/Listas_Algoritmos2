#include<stdio.h>
#include<string.h>
int main(){
	int i;
	char nome1[100], nome2[100], caractere[3000];
	printf("qual o nome do arq de entrada?\n");
	scanf("%s",nome1);
	getchar();
	printf("e do de saida?");
	scanf("%s",nome2);
	getchar();
	FILE*arquivo1;
	FILE*arquivo2;
	if((arquivo1=fopen(nome1,"r"))==NULL){
		printf("erro");
		exit(1);
	}
	if((arquivo2=fopen(nome2,"w"))==NULL){
		printf("erro");
		exit(1);
	}
	i=0;
	while(1){
		int i = 0;
        char c;
        while ((c = getc(arquivo1)) != EOF && c != '\n') {
             caractere[i++] = c;
            }

        if (i == 0 && c == EOF) {
            break; 
			}
        if (c == '\n') {
            caractere[i++] = '\n';
        }
	  caractere[i] = '\0'; 
        for (int j = i - 1; j >= 0; j--) {
            putc(caractere[j], arquivo2);
        }
    }
	fclose(arquivo1);
	fclose(arquivo2);
}