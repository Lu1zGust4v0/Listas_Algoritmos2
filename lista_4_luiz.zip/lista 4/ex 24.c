#include<stdio.h>
#include <stdlib.h>
#include<string.h>
int main(){
	int ii,aa=0,bb=0,v=0, num,j,x;
	char texto1[3000],*c, texto2[3000],*str, texto3[3000], let[26];
	FILE*arquivo1, *arquivo2;
	if((arquivo1=fopen("texto.txt","r"))==NULL){
		printf("erro1");
		return 0;
	}
	
	while((fgets(texto1,3000,arquivo1))!=NULL)
	x=strlen(texto1);
	strcpy(texto3,texto1);
	strcpy(texto2,texto1);
	c = strtok(texto1, " .,\n");
	while(c!=NULL){
		aa++;
		c = strtok(NULL, " .,\n");
	}
	str = strtok(texto2, "\n");
	while(str!=NULL){
		bb++;
		str = strtok(NULL, "\n");
	}
	printf("quantas letras vc quer saber?\n");
	scanf("%d",&num);
	printf("\nquais?\n");
	for(int i=0;i<num;i++)
		scanf(" %c",&let[i]);
	
	
	for(j=0;j<num;j++){
	for(ii=0;ii<strlen(texto3);ii++){
		if(texto3[ii]==let[j])
			v++;
	}
	printf("%c aparece %d vezes",let[j],v);
	v=0;
	}
	printf("tem %d palavras, %d letras e %d linhas\n", aa,x,bb);
	fclose(arquivo1);
}
	