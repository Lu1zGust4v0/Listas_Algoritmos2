#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include<ctype.h>

typedef struct reg *no;
struct reg {
    int info;
    no ant, prox; 
};
void cria_LLDE (no *lista) {
  *lista = NULL;
} 
void mostra_LLDE (no lista){
  if (lista == NULL) {
    printf ("\n\nLista vazia");
    return;
  }
  no p = lista;
  printf ("\n\nElementos da lista: ");
  do {
    printf ("%d ",p->info);
    p = p->prox;
  } while (p != NULL);
}
void mostra_LLDE_contrario (no lista){
  if (lista == NULL) {
    printf ("\nLista vazia");
    return;
  }
  no p = lista;
  while (p->prox != NULL)
    p = p->prox;
  printf ("\nElementos da lista ao contrario: ");
  do {
    printf ("%d ",p->info);
    p = p->ant;
  } while (p != NULL);
}
void inclui_inicio_LLDE (no *lista, int info) {
  no p = (no) malloc(sizeof(struct reg ));
  p->ant = NULL;  
  p->info = info;
  p->prox = *lista;
  if (*lista) 
    (*lista)->ant = p;
  *lista = p;
}

void remover(no*lista){
	no q,p=*lista;
	while(p->prox){
		q=p;
		p=p->prox;
}
	q->prox=NULL;
	free(p);
}
int main () {
  no lista;    
  int info;
  char resp;
	lista = NULL;
  do {
     printf ("\nDigite um numero inteiro: ");
     scanf ("%d",&info);
     inclui_inicio_LLDE (&lista,info);
     mostra_LLDE (lista);
     mostra_LLDE_contrario (lista);            
     printf ("\nContinua (S/N)? \n");   
     do {
        resp = toupper(getch());
     } while (resp!='N' && resp!='S');
  } while (resp!='N');
  remover(&lista);
  mostra_LLDE (lista);
}   