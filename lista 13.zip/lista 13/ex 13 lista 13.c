#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include<ctype.h>

typedef struct reg *no;
struct reg {
    int info;
    no ant, prox;  
};
void inclui(no*lista, int info){
	no p=(no)malloc(sizeof(struct reg));
	p->info=info;
	p->ant=NULL;
	if(!*lista)
		*lista=p;
	else{
		(*lista)->ant=p;
		p->prox=*lista;
		*lista=p;
}}
void mostra(no lista){
	no p =lista;
	while(p){
		printf("%d ",p->info);
		p=p->prox;	
}	
}
int conta(no lista){
	int a=0;
	no p = lista;
	while(p){
		a++;
		p=p->prox;
		}
	return a;
}

void remover(no*lista, int info){
	no q,p=*lista;
	while(p->info==info){
		q=p->prox;
		q->ant=NULL;
		*lista=q;
		free(p);
		p=q;
	}
	p=p->prox;
	q=p->ant;
	while(p){
		if(p->info==info){
			q->prox=p->prox;
			if(p->prox)
			p->prox->ant=q;	
			free(p);
			p=q;
		}
		q=p;
		p=p->prox;
	}
} 
int main () {
  no lista;    
  int info,num;
  char resp;
  lista = NULL;
  do {
     printf ("\nDigite um numero inteiro: ");
     scanf ("%d",&info);
     inclui (&lista,info);
     mostra (lista);         
     printf ("\nContinua (S/N)? \n");   
     do {
        resp = toupper(getch());
     } while (resp!='N' && resp!='S');
  } while (resp!='N');
  conta(lista);
  printf("\nqual elemento vc quer remover?");
  scanf("%d",&info);
  remover(&lista,info);
  mostra (lista); 
}