#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include<ctype.h>

typedef struct reg *no;
struct reg {
    int info;
    no ant, prox; 
};
void cria_LLDE (no *lista) {
  *lista = NULL;
} 
void mostra_LLDE (no lista){
  if (lista == NULL) {
    printf ("\n\nLista vazia");
    return;
  }
  no p = lista;
  printf ("\n\nElementos da lista: ");
  do {
    printf ("%d ",p->info);
    p = p->prox;
  } while (p != NULL);
}
void mostra_LLDE_contrario (no lista){
  if (lista == NULL) {
    printf ("\nLista vazia");
    return;
  }
  no p = lista;
  while (p->prox != NULL)
    p = p->prox;
  printf ("\nElementos da lista ao contrario: ");
  do {
    printf ("%d ",p->info);
    p = p->ant;
  } while (p != NULL);
}
void inclui_ord(no *lista, int info) {
	no r,q = *lista;
	no p =(no)malloc(sizeof(struct reg));
	p->info=info;
	if(!*lista){
		*lista=p;
		p->prox=NULL;
		p->ant=NULL;
		return;
	}
	if(q->info>info){
		p->prox=*lista;
		(*lista)->ant=p;
		p->ant=NULL;
		*lista=p;
		return;
	}
	while(q&&q->info<info){
		r=q;
		q=q->prox;
	}
	if(q){
		r->prox=p;
		p->ant=r;
		p->prox=q;
		q->ant=p;
	}
	else{
		r->prox=p;
		p->ant=r;
		p->prox=NULL;
	}
		
	}
void inverte(no*lista){
	no q,r,p=*lista;
	if(!p->prox)
		return;
	q=p;
	p=p->prox;
	q->prox=NULL;
	r=p;
	while(p){
		p=p->prox;
		r->prox=q;
		q->ant=r;
		q=r;
		r=p;
	}
	*lista=q;
}

int main () {
  no lista,lista2;    
  int info;
  char resp;
  lista2=NULL;
	lista = NULL;
  do {
     printf ("\nDigite um numero inteiro p 1: ");
     scanf ("%d",&info);
     inclui_ord (&lista,info);
     mostra_LLDE (lista);
     mostra_LLDE_contrario (lista);            
     printf ("\nContinua (S/N)? \n");   
     do {
        resp = toupper(getchar());
     } while (resp!='N' && resp!='S');
  } while (resp!='N');
 inverte(&lista);
 mostra_LLDE (lista);
}   