#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include<ctype.h>

typedef struct reg *no;
struct reg {
    int info;
    no ant, prox;  
};
void inclui(no*lista, int info){
	no p=(no)malloc(sizeof(struct reg));
	p->info=info;
	p->ant=NULL;
	if(!*lista)
		*lista=p;
	else{
		(*lista)->ant=p;
		p->prox=*lista;
		*lista=p;
}}
void mostra(no lista){
	no p =lista;
	while(p->prox){
		printf("%d ",p->info);
		p=p->prox;	
}	
	printf("ultimo: %d",p->info);
}
void conta(no lista){
	int a=0;
	no p = lista;
	while(p){
		a++;
		p=p->prox;
		}
		printf("%d nos",a);
}
int main () {
  no lista;    
  int info;
  char resp;
  lista = NULL;
  do {
     printf ("\nDigite um numero inteiro: ");
     scanf ("%d",&info);
     inclui (&lista,info);
     mostra (lista);         
     printf ("\nContinua (S/N)? \n");   
     do {
        resp = toupper(getch());
     } while (resp!='N' && resp!='S');
  } while (resp!='N');
  conta(lista);
}