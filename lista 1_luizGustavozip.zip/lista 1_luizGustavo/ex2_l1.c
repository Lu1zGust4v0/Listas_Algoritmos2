#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void comparar(char comp[], char compa[]){
	int a=0, b=0, i;
	
		for(int i=0;i<strlen(comp);i++){
			if(comp[i]==compa[i])
				a++;	
		}
		if(a==strlen(comp)-1){
			return printf("sao iguais");
		}
			i=0;
		else{
			while(b==0){
				if(comp[i]!= compa[i]){
						b=1;
						if(comp[i]<compa[i]){
							return printf("A segunda é maior");
						}
						else {
							return printf("a primeira é maior")
						}
							
				}
				 
			i++;
			}
			
		}
}


int main(){
	char frase[200], frase2[200];
	printf("digite a primeira string");
	gets(frase);
	
	printf("agr a segunda");
	gets(frase2);
	
	comparar(frase, frase2);
	
}