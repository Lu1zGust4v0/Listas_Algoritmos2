#include<stdio.h>
#include<string.h>

int main(){
	int a=0, i, j=0;
	char c, frase[300];
	
	while(j==0){
		gets(frase);
	for(i=0;i<strlen(frase);i++){
		if(frase[i]== ' ')
			a++;
	}
	printf("%d palavras, se quer repetir digite 0\n", a+1);
	scanf("%d", &j);
	a =0;
}
}