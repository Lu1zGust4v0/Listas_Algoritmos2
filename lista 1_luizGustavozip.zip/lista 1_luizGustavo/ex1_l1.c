#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(){
	char frase[200];
	gets(frase);
	for(int i=0;i<strlen(frase);i++){
		
		if(frase[i]>96 && frase[i]<123)
			frase[i]=frase[i]-32;
		
		printf("%c", frase[i]);
	}
	
}