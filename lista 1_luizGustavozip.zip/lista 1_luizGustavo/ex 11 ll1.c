#include<stdio.h>
#include<string.h>
int main(){
	char str[200], str1[200], c;
	printf("digite a frase 1\n");
	gets(str1);
	fflush(stdin);
	printf("\n agr a segunda\n");
	gets(str);
	
	char vogais[] = "aeiouAEIOU";
    
    for (int i = 0; i < strlen(str); i++) {
        if (strchr(vogais, str[i])) {
            str[i] = '*';
        }
    }
    
    for (int i = 0; i < strlen(str1); i++) {
        if (strchr(vogais, str1[i])) {
            str1[i] = '*';
        }}
	for(int i=strlen(str)-1;i>=0;i--){
		printf("%c", str[i]);
	}
	printf("\n");
	for(int i=strlen(str1)-1;i>=0;i--){
		printf("%c", str1[i]);
	}
}