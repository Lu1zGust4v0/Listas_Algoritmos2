#include<stdio.h>
#include<string.h>

int main(){
	int a, i, j;
	char c, frase[300];
	gets(frase);
	
	for(i=0;i<strlen(frase);i++){
		for(int j=i;j<strlen(frase);j++){
			if(frase[i]>frase[j]){
				c = frase[i];
				frase[i]=frase[j];
				frase[j]=c ;
			}	
		}
	}
	printf("%s", frase);
}