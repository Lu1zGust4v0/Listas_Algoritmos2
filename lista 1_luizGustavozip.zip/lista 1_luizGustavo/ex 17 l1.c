#include<stdio.h>
#include<string.h>

int main(){
	int a=0, i, j;
	char c, frase[300];
	gets(frase);
	
	for(i=0;i<strlen(frase);i++){
		if(frase[i]!=frase[strlen(frase)-1-i])
			a=1;
	}
	if(a==0)
		printf("eh palindromo");
	else
		printf("nao eh palindromo");
}