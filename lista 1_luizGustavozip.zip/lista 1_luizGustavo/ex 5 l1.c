#include<stdio.h>
#include<string.h>
int main(){
	char str[200];
	
	gets(str);
	
	for(int i=0;i<strlen(str);i++){
		if(str[i]!= 97 && str[i]!= 101  && str[i]!= 105  && str[i]!= 111  && str[i]!= 117  && str[i]!= 65  && str[i]!= 69  && str[i]!= 73  && str[i]!= 79  && str[i]!= 85) 
			printf("%c", str[i]);
	}
	
}