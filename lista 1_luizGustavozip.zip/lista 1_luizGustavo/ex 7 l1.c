#include<stdio.h>
#include<string.h>
int main(){
	char str[200], c;
	printf("digite o caractere\n");
	scanf("%c", &c);
	fflush(stdin);
	printf("\n agr a string\n");
	gets(str);
	
	for(int i=0;i<strlen(str);i++){
		str[i]=c;
	}
	printf("%s", str);
}