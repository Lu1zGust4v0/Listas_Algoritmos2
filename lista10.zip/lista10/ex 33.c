#include<stdio.h>
#include <stdlib.h>
#include<ctype.h>
#include<string.h>
typedef struct reg *no;
struct reg {
    int info;
    struct reg *prox;
};
void cria_lista (no *lista) {
  *lista = NULL;
} 
void mostra_lista (no lista) {
  no p = lista;
  printf ("\nElementos da lista: ");
  while (p) {
    printf ("%d ",p->info);
    p = p->prox;
  }
}
int conta_nos (no lista){
  no p = lista;
  int cont = 0;
  while (p){
    cont++;
    p = p->prox;
  }
  return cont;
}

void inclui_ord (no *lista, int info){
  no p = (no) malloc(sizeof(struct reg));
  p->info = info;
  no q = *lista;
  if((*lista)==NULL||q->info>=info){
  	p->prox=*lista;
  	(*lista)=p;
  }
  else{
  	no r;
  	while (q != NULL && q->info < info){
      r = q;
      q = q->prox;
    }      
    p->prox = q; 
    r->prox = p;
}
}

int busca_lista (no lista, int info) {
  no p = lista;
  while (p) {
    if (p->info == info)
      return 1;
    p = p->prox;
  }    
  return 0;
}

void remover(no *lista,int info){
	no q = *lista;
	no p=NULL;
	while(q){
		if(q->info==info){
			if(p==NULL)
				*lista=q->prox;
			else
				p->prox=q->prox;
			p =q;
			q=q->prox;
			free(p);
		}
		else{
			p=q;
			q=q->prox;	
	}
}}
void concatenar(no *lista1,no lista2){
	no p=*lista1;
	if(*lista1==NULL)
		*lista1=lista2;
	else{
		while(p->prox)
			p=p->prox;
		p->prox=lista2;
		
}}
int main () {
  int info;
  no lista,lista2,lista3;
  lista2=NULL;    
  char resp;
  cria_lista (&lista); 
  do {
    printf ("\nDigite um numero inteiro para lista 1: ");
    scanf ("%d",&info);
    inclui_ord (&lista,info);
    mostra_lista (lista);
    printf ("\nQuantidade de elementos na lista 1: %d",conta_nos(lista));
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N'); 
  do {
    printf ("\nDigite um numero inteiro para lista 2: ");
    scanf ("%d",&info);
    inclui_ord (&lista2,info);
    mostra_lista (lista2);
    printf ("\nQuantidade de elementos na lista 2: %d",conta_nos(lista2));
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
  concatenar(&lista,lista2);
  mostra_lista(lista);
}      