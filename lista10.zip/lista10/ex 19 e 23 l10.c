#include<stdio.h>
#include <stdlib.h>
#include<ctype.h>
#include<string.h>
typedef struct reg *no;
struct reg {
    int info;
    struct reg *prox;
};
void cria_lista (no *lista) {
  *lista = NULL;
} 
void mostra_lista (no lista) {
  no p = lista;
  printf ("\nElementos da lista: ");
  while (p) {
    printf ("%d ",p->info);
    p = p->prox;
  }
}
int conta_nos (no lista){
  no p = lista;
  int cont = 0;
  while (p){
    cont++;
    p = p->prox;
  }
  return cont;
}

void inclui_final (no *lista, int info){
  no p = (no) malloc(sizeof(struct reg));
  p->info = info;
  p->prox = NULL;
  if (*lista == NULL)
    *lista = p;
  else {
    no q = *lista;
    while (q->prox)
      q = q->prox;
    q->prox = p;
  }
}

int busca_lista (no lista, int info) {
  no p = lista;
  while (p) {
    if (p->info == info)
      return 1;
    p = p->prox;
  }    
  return 0;
}

void remover(no *lista,int info){
	no q = *lista;
	no p=NULL;
	while(q){
		if(q->info==info){
			if(p==NULL)
				*lista=q->prox;
			else
				p->prox=q->prox;
			p =q;
			q=q->prox;
			free(p);
		}
		else{
			p=q;
			q=q->prox;	
	}
}}
int main () {
  int info;
  no lista;    
  char resp;
  cria_lista (&lista); 
  do {
    printf ("\nDigite um numero inteiro: ");
    scanf ("%d",&info);
    inclui_final (&lista,info);
    mostra_lista (lista);
    printf ("\nQuantidade de elementos na lista: %d",conta_nos(lista));
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
  printf("qual elemento vc quer remover?");
  scanf("%d",&info);
  remover(&lista,info);
  printf("\nlista com o elemento removido:");
  mostra_lista(lista);  
}      