#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct reg *no;

struct reg {
    int info;
    struct reg *prox;
};

void inclui(no *lista, int info) {
    no p = (no)malloc(sizeof(struct reg));
    p->info = info;
    p->prox = NULL;
    
    if (!*lista) {
        *lista = p;
    } else {
        no q = *lista;
        while (q->prox) {
            q = q->prox;
        }
        q->prox = p;
    }
}

void mostra(no lista) {
    int cont = 0;
    no p = lista;
    printf("Elementos: ");
    while (p) {
        cont++;
        printf("%d ", p->info);
        p = p->prox;
    }
    printf("\n%d elementos\n", cont);
}

void remove(no*lista){
	no p =*lista;
	while(p->prox){
		no q = p;
		no r = p->prox;
		while(r){
			if(p->info==r->info){
				q->prox=r->prox;
				free(r);
				r=q->prox;
			}
			else{
				q=r;
				r=r->prox;
			}
		}
		p=p->prox;
	}
}




int main() {
    int info;
    char resp;
    no lista = NULL;
    
    do {
        printf("Digite um numero: ");
        scanf("%d", &info);
        inclui(&lista, info);
        mostra(lista);
        
        printf("\n\nContinua? (s/n): ");
        while ((getchar()) != '\n');
        
        resp = toupper(getchar());
    } while (resp != 'N');
    
    remove(&lista);
    printf("\nLista apos remover duplicados:\n");
    mostra(lista);
    
    return 0;
}
