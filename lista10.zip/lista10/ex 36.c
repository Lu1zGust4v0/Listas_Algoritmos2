#include<stdio.h>
#include <stdlib.h>
#include<ctype.h>
#include<string.h>
typedef struct reg *no;
struct reg {
    int info;
    struct reg *prox;
};
void cria_lista (no *lista) {
  *lista = NULL;
} 
void mostra_lista (no lista) {
  no p = lista;
  printf ("\nElementos da lista: ");
  while (p) {
    printf ("%d ",p->info);
    p = p->prox;
  }
}
int conta_nos (no lista){
  no p = lista;
  int cont = 0;
  while (p){
    cont++;
    p = p->prox;
  }
  return cont;
}

void inclui_ord (no *lista, int info){
  no p = (no) malloc(sizeof(struct reg));
  p->info = info;
  no q = *lista;
  if((*lista)==NULL||q->info>=info){
  	p->prox=*lista;
  	(*lista)=p;
  }
  else{
  	no r;
  	while (q != NULL && q->info < info){
      r = q;
      q = q->prox;
    }      
    p->prox = q; 
    r->prox = p;
}
}
void alternar(no l1,no l2,no*lista3){
	no p =l1;
	no q=l2;
	*lista3=p;
	p=p->prox;
	no r=*lista3;
	while(p&&q){
		r->prox=q;
		r=q;
		q=q->prox;
		r->prox=p;
		r=p;
		p=p->prox;
	}
	if(p)
		r->prox=p;
	else{
		r->prox=q;
}
}
	
void dividir(no l1,no*lista2,no*lista3,int a){
	no p =l1,q;
	*lista2=p;
	p=p->prox;
	q=*lista2;
	int b=1;
		while(b<(a+1)/2){
			b++;
			q->prox=p;
			q=p;
			p=p->prox;
		}
		q->prox=NULL;
	*lista3=p;
	no r =*lista3;
	p=p->prox;
		while(p){
			r->prox=p;
			r=p;
			p=p->prox;
		}	
}
int main () {
  int info,a;
  no lista,lista2,lista3;
  lista2=NULL;    
  char resp;
  cria_lista (&lista);
  lista3 =NULL; 
  do {
    printf ("\nDigite um numero inteiro para lista 1: ");
    scanf ("%d",&info);
    inclui_ord (&lista,info);
    mostra_lista (lista);
    printf ("\nQuantidade de elementos na lista 1: %d",conta_nos(lista));
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N'); 
	a = conta_nos(lista);
  dividir(lista,&lista2,&lista3,a);
  printf("\nLista l2 :");
  mostra_lista(lista2);
  printf("\nL3:");
  mostra_lista(lista3);
}      