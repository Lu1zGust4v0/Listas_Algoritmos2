#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
typedef struct reg*no;

struct reg{
	int info;
	struct reg*prox;
};

void inclui(no *lista, int info){
	no p = (no)malloc(sizeof(struct reg));
	p->info = info;
	no q =*lista;
	p->prox=NULL;
	if(!*lista)
		*lista =p;
	else{
		while(q->prox)
			q=q->prox;
		q->prox=p;		
}}

void mostra(no lista){
	int cont =0;
	no p = lista;
	printf("elementos:");
	while(p){
		cont++;
		printf("%d ",p->info);
		p=p->prox;
	}
	printf("\n%d elementos",cont);
}

void inserirmeio(no*lista,int num,int info){
	no p = (no)malloc(sizeof(struct reg));
	p->info = info;
	int a=0;
	no q =*lista;
	if(num!=1){
	while(q){
		a++;
		if(a+1==num){
			p->prox=q->prox;
			q->prox=p;
	}
}
}
int main(){
	int info,num;
	no lista = NULL;
	char resp; 
	
	do{
		printf("digite um numero");
		scanf("%d",&info);
		inclui(&lista,info);
		mostra(lista);
		printf("\n\ncontinua? (s/n)");
		do{
			resp= toupper(getchar());
		}while(resp!='N'&&resp!='S');
	}while(resp!='N');
	printf("vc quer inserir o proximo elemento antes de quantos termos?\n");
	scanf("%d",&num);
	printf("e qual o elemento que vc quer inserir?");
	scanf("%d",&info);
	inserirmeio(&lista,num,info);
	mostra(lista);
}}