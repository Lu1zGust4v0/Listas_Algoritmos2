#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
typedef struct reg*no;

struct reg{
	int info;
	struct reg*prox;
};

void inclui(no *lista, int info){
	no p = (no)malloc(sizeof(struct reg));
	p->info = info;
	p->prox = *lista;
	*lista = p;
}

void mostra(no lista){
	int cont =0;
	no p = lista;
	no q;
	printf("elemento do ultimo no:");
	while(p){
		q=p;
		p=p->prox;
	}
	printf("\n%d ",q->info);
}
int main(){
	int info;
	no lista = NULL;
	char resp; 
	
	do{
		printf("digite um numero");
		scanf("%d",&info);
		inclui(&lista,info);
		mostra(lista);
		printf("\n\ncontinua? (s/n)");
		do{
			resp= toupper(getchar());
		}while(resp!='N'&&resp!='S');
	}while(resp!='N');
	
}