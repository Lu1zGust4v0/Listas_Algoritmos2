#include<stdio.h>
#include <stdlib.h>
#include<ctype.h>
#include<string.h>
typedef struct reg *no;
struct reg {
    int info;
    struct reg *prox;
};
void cria_lista (no *lista) {
  *lista = NULL;
} 
void mostra_lista (no lista) {
  no p = lista;
  printf ("\nElementos da lista: ");
  while (p) {
    printf ("%d ",p->info);
    p = p->prox;
  }
}

void inclui_ord (no *lista, int info){
  no p = (no) malloc(sizeof(struct reg));
  p->info = info;
  no q = *lista;
  if((*lista)==NULL||q->info>=info){
  	p->prox=*lista;
  	(*lista)=p;
  }
  else{
  	no r;
  	while (q != NULL && q->info < info){
      r = q;
      q = q->prox;
    }      
    p->prox = q; 
    r->prox = p;
}
}

void copiaa(no lista, no *copia) {
  no p = lista, r;
  *copia = NULL;
  while (p != NULL){
  	no q = (no) malloc(sizeof(struct reg));
  	q->info = p->info;
  	q->prox = NULL;
    if (*copia == NULL) 
	    *copia = q;
	  else
	    r->prox = q;
	 r = q;  
 	 p = p->prox;    	
  }
}
int main () {
  int info;
  no lista,copia;
  copia=NULL;    
  char resp;
  cria_lista (&lista); 
  do {
    printf ("\nDigite um numero inteiro para lista 1: ");
    scanf ("%d",&info);
    inclui_ord (&lista,info);
    mostra_lista (lista);
    printf ("\nQuantidade de elementos na lista 1: %d",conta_nos(lista));
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N'); 
  copiaa(lista,&copia);
  mostra_lista(copia);
}      