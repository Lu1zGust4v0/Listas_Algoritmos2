#include<stdio.h>
#include <stdlib.h>
#include<ctype.h>
#include<string.h>
typedef struct reg *no;
struct reg {
    int info;
    struct reg *prox;
};
void cria_lista (no *lista) {
  *lista = NULL;
} 
void mostra_lista (no lista) {
  no p = lista;
  printf ("\nElementos da lista: ");
  while (p) {
    printf ("%d ",p->info);
    p = p->prox;
  }
}

void inclui_ord (no *lista, int info){
  no p = (no) malloc(sizeof(struct reg));
  p->info = info;
  no q = *lista;
  if((*lista)==NULL||q->info>=info){
  	p->prox=*lista;
  	(*lista)=p;
  }
  else{
  	no r;
  	while (q != NULL && q->info < info){
      r = q;
      q = q->prox;
    }      
    p->prox = q; 
    r->prox = p;
}
}

void maior(no lista){
	int a;
	no p =lista;
	if(p){
		a = p->info;
		p=p->prox;
		while(p){
			if(p->info>a)
				a=p->info;
			p=p->prox;
	}
}
	printf("%d o maior",a);
}

void menor(no lista){
	int a;
	no p =lista;
	if(p){
		a = p->info;
		p=p->prox;
		while(p){
			if(p->info<a)
				a=p->info;
			p=p->prox;
	}
}
	printf("%d o menor",a);
}

int main () {
  int info;
  no lista,copia;
  copia=NULL;    
  char resp;
  cria_lista (&lista); 
  do {
    printf ("\nDigite um numero inteiro para lista 1: ");
    scanf ("%d",&info);
    inclui_ord (&lista,info);
    mostra_lista (lista);
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N'); 
  maior(lista);
  menor(lista);
}      