#include<stdio.h>
#include <stdlib.h>
#include<ctype.h>
#include<string.h>
typedef struct reg *no;
struct reg {
    int info;
    struct reg *prox;
};
void cria_lista (no *lista) {
  *lista = NULL;
} 
void mostra_lista (no lista) {
  no p = lista;
  printf ("\nElementos da lista: ");
  while (p) {
    printf ("%d ",p->info);
    p = p->prox;
  }
}
int conta_nos (no lista){
  no p = lista;
  int cont = 0;
  while (p){
    cont++;
    p = p->prox;
  }
  return cont;
}

void inclui_ord (no *lista, int info){
  no p = (no) malloc(sizeof(struct reg));
  p->info = info;
  no q = *lista;
  if((*lista)==NULL||q->info>=info){
  	p->prox=*lista;
  	(*lista)=p;
  }
  else{
  	no r;
  	while (q != NULL && q->info < info){
      r = q;
      q = q->prox;
    }      
    p->prox = q; 
    r->prox = p;
}
}
void ordenar(no l1, no l2, no *lista3) {
    no p = l1;
    no q = l2;
    no s = NULL, ultimo = NULL;
    if (p && (!q || p->info <= q->info)) {
        *lista3 = p;
        p = p->prox;
    } else if (q) {
        *lista3 = q;
        q = q->prox;
    }
    ultimo = *lista3;
    while (p && q) {
        if (p->info <= q->info) {
            ultimo->prox = p;
            p = p->prox;
        } else {
            ultimo->prox = q;
            q = q->prox;
        }
        ultimo = ultimo->prox; 
    }
    if (p) {
        ultimo->prox = p;
    } else if (q) {
        ultimo->prox = q;
    }
}
void concatena_lista (no *l1, no l2) {
  if (*l1==NULL){
    *l1 = l2;
    return;
  }
  no p = *l1;
  while (p->prox != NULL)
    p = p->prox;
  p->prox = l2;  
}
int main () {
  int info;
  no lista,lista2,lista3;
  lista2=NULL;    
  char resp;
  cria_lista (&lista);
  lista3 =NULL; 
  do {
    printf ("\nDigite um numero inteiro para lista 1: ");
    scanf ("%d",&info);
    inclui_ord (&lista,info);
    mostra_lista (lista);
    printf ("\nQuantidade de elementos na lista 1: %d",conta_nos(lista));
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N'); 
  do {
    printf ("\nDigite um numero inteiro para lista 2: ");
    scanf ("%d",&info);
    inclui_ord (&lista2,info);
    mostra_lista (lista2);
    printf ("\nQuantidade de elementos na lista 2: %d",conta_nos(lista2));
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
  ordenar(lista,lista2,&lista3);
  printf("\nLista l3 ordenada:");
  mostra_lista(lista3);
}      