#include<stdio.h>
#include <stdlib.h>
#include <time.h>
struct soldados{
	char nome[200];
};
int main(){
	struct soldados soldado[1000];
	int j,i=0,num,b,n=0,a,random;
	do{
	printf("1- sortear soldado a partir do primeiro\n2- sortear a partir de um numero\n3- sortear a partir do ultimo sorteado\n4- adicionar soldado\n5- sair\n");
	scanf("%d",&num);
	getchar();
	if(num==1){	
		system("cls");
		if (i == 0) {
                printf("Nenhum soldado adicionado ainda.\n");
            } 
        else{
		srand(time(NULL));
    random = (rand() % i);
    a = random;
    printf("o soldado %s foi sorteado, numero %d\n",soldado[random].nome,random+1);
	}
	for(j=random;j<i-1;j++)
		strcpy(soldado[j].nome,soldado[j+1].nome);
	i--;
	}
	if(num==2){
		printf("qual numero?\n");
		scanf("%d",&b);
		
		system("cls");
		if (i == 0) {
                printf("Nenhum soldado adicionado ainda.\n");
            }
		else{
		srand(time(NULL));
    random = (rand() % i);
    a = random;
    if(b+random<i){
    	printf("o soldado %s foi sorteado, numero %d\n",soldado[b+random].nome,b+random+1);
    	for(j=random+b;j<i-1;j++)
		strcpy(soldado[j].nome,soldado[j+1].nome);
		i--;
	}
    else{
    	printf("o soldado %s foi sorteado, numero %d\n",soldado[b+random-i].nome,b-i+random+1);
    	for(j=b+random-i;j<i-1;j++)
			strcpy(soldado[j].nome,soldado[j+1].nome);
		i--;
	}
	}
}
	if(num==3){
		system("cls");
		if (i == 0) {
                printf("Nenhum soldado adicionado ainda.\n");
            }
		else{
		srand(time(NULL));
    random = (rand() % i);
    if(a+random<i)
    	printf("o soldado %s foi sorteado, numero %d\n",soldado[a+random].nome,a+random+1);
    else
    	printf("o soldado %s foi sorteado, numero %d\n",soldado[a+random-i].nome,a-i+random+1);
	}}
	if(num==4){
		system("cls");
		printf("qual o nome?\n");
		gets(soldado[i].nome);
		fflush(stdin);
		i++;
	}
}while(num!=5);
}