#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct soldados {
    int dia, mes, ano,hora, minuto,segundo;
};

int main() {
	srand(time(NULL));
    struct soldados soldado[20];
    int i;
    for(i=0;i<20;i++){
    	soldado[i].dia =(rand()%20)+1;
    	soldado[i].mes = (rand()%12)+1;
    	soldado[i].ano=(rand()%9)+2016;
    	soldado[i].hora=(rand()%24);
    	soldado[i].minuto=(rand()%60);
    	soldado[i].segundo=(rand()%60);
	}
	for(i=0;i<20;i++){
		printf("Compromisso %d\n",i+1);
		printf("Data: %02d/%02d/%02d\n",soldado[i].dia,soldado[i].mes,soldado[i].ano);
		printf("Horario: %02d:%02d:%02d\n",soldado[i].hora,soldado[i].minuto,soldado[i].segundo);
		printf("Texto: Compromisso de teste gerado aleatoriamente.\n");
	}
    
    
    return 0;
}
