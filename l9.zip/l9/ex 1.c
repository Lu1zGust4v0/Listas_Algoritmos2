#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>
struct pessoas{
	char nome[290], numero[15], email[100],rua[130], complemento[29],bairro[20], cep[10],cidade[19],estado[20], pais[30];
	int dia, mes, ano,ddd;
};

int main(){
	int num,n=0,i;
	struct pessoas pessoa[101];
	do{do{
	printf("1- BUSCA POR PRIMEIRO NOME\n");
	printf("2- BUSCA POR MES DE ANIVERSARIO\n");
	printf("3- BUSCA POR DIA E MES DE ANIVERSARIO\n");
	printf("4- IMPRIMIR AGENDA\n");
	printf("5- INSERIR PESSOA\n");
	printf("6- RETIRA PESSOA\n");
	printf("7- SAIR");
	scanf("%d",&num);
}while(num<1 || num>6);
	getchar();
	system("cls");
	if (num == 1) {
    int a = 0;
    char nome[290];
    printf("\nQual o nome?\n");
    gets(nome);
    fflush(stdin);
    for (i = 0; i < n; i++) {
        if (strcmp(nome, pessoa[i].nome) == 0) { 
            a = 1;
            printf("\nNome: %s\nEmail: %s\nPais: %s\nEstado: %s\nCEP: %s\nCidade: %s\nBairro: %s\nRua: %s\nComplemento: %s\nDDD: %d\nNumero: %s\nData de Nascimento: %d/%d/%d\n", 
                   pessoa[i].nome, pessoa[i].email, pessoa[i].pais, pessoa[i].estado, pessoa[i].cep, pessoa[i].cidade, pessoa[i].bairro, pessoa[i].rua, pessoa[i].complemento, pessoa[i].ddd, pessoa[i].numero, pessoa[i].dia, pessoa[i].mes, pessoa[i].ano);
        }
    }
    if (!a) {
        printf("Não encontrado\n");
    }
}

	if (num == 2) {
    int m, a = 0;
    printf("\nQual o mês?\n");
    scanf("%d", &m);
    getchar();
    for (i = 0; i < n; i++) {
        if (m == pessoa[i].mes) { 
            a = 1;
            printf("\nNome: %s\nEmail: %s\nPais: %s\nEstado: %s\nCEP: %s\nCidade: %s\nBairro: %s\nRua: %s\nComplemento: %s\nDDD: %d\nNumero: %s\nData de Nascimento: %d/%d/%d\n", 
                   pessoa[i].nome, pessoa[i].email, pessoa[i].pais, pessoa[i].estado, pessoa[i].cep, pessoa[i].cidade, pessoa[i].bairro, pessoa[i].rua, pessoa[i].complemento, pessoa[i].ddd, pessoa[i].numero, pessoa[i].dia, pessoa[i].mes, pessoa[i].ano);
        }
    }
    if (!a) {
        printf("Não encontrado\n");
    }
}

	if (num == 3) {
    int d, m, a = 0;
    printf("\nQual o dia e mês?\n");
    scanf("%d %d", &d, &m);
    getchar();
    for (i = 0; i < n; i++) {
        if (d == pessoa[i].dia && m == pessoa[i].mes) { 
            a = 1;
            printf("\nNome: %s\nEmail: %s\nPais: %s\nEstado: %s\nCEP: %s\nCidade: %s\nBairro: %s\nRua: %s\nComplemento: %s\nDDD: %d\nNumero: %s\nData de Nascimento: %d/%d/%d\n", 
                   pessoa[i].nome, pessoa[i].email, pessoa[i].pais, pessoa[i].estado, pessoa[i].cep, pessoa[i].cidade, pessoa[i].bairro, pessoa[i].rua, pessoa[i].complemento, pessoa[i].ddd, pessoa[i].numero, pessoa[i].dia, pessoa[i].mes, pessoa[i].ano);
        }
    }
    if (!a) {
        printf("Não encontrado\n");
    }
}

	if (num == 4) {
    if (n == 0) {
        printf("A agenda está vazia.\n");
    } else {
        for (i = 0; i < n; i++) {
            printf("\nNome: %s\nEmail: %s\nPais: %s\nEstado: %s\nCEP: %s\nCidade: %s\nBairro: %s\nRua: %s\nComplemento: %s\nDDD: %d\nNumero: %s\nData de Nascimento: %d/%d/%d\n", 
                    pessoa[i].nome, pessoa[i].email, pessoa[i].pais, pessoa[i].estado, pessoa[i].cep, pessoa[i].cidade, pessoa[i].bairro, pessoa[i].rua, pessoa[i].complemento, pessoa[i].ddd, pessoa[i].numero, pessoa[i].dia, pessoa[i].mes, pessoa[i].ano);
        }
    }
}

	if (num == 5) {
		printf("Nome? ");
		gets(pessoa[n].nome);
		fflush(stdin);

		printf("Email? ");
		gets(pessoa[n].email);
		fflush(stdin);

		printf("Pais? ");
		gets(pessoa[n].pais);
		fflush(stdin);

		printf("Estado? ");
		gets(pessoa[n].estado);
		fflush(stdin);

		printf("CEP? ");
		gets(pessoa[n].cep);
		fflush(stdin);

		printf("Cidade? ");
		gets(pessoa[n].cidade);
		fflush(stdin);

		printf("Bairro? ");
		gets(pessoa[n].bairro);
		fflush(stdin);

		printf("Rua? ");
		gets(pessoa[n].rua);
		fflush(stdin);

		printf("Complemento? ");
		gets(pessoa[n].complemento);
		fflush(stdin);

		printf("DDD? ");
		scanf("%d", &pessoa[n].ddd);
		fflush(stdin);

		printf("Numero? ");
		gets(pessoa[n].numero);
		fflush(stdin);

		printf("Dia do nascimento? ");
		scanf("%d", &pessoa[n].dia);
		fflush(stdin);

		printf("Mes do nascimento? ");
		scanf("%d", &pessoa[n].mes);
		fflush(stdin);

		printf("Ano do nascimento? ");
		scanf("%d", &pessoa[n].ano);
		fflush(stdin);

		n++;
		
		for (i = n - 1; i > 0 && strcmp(pessoa[i - 1].nome, pessoa[i].nome) > 0; i--) {
                struct pessoas temp = pessoa[i];
                pessoa[i] = pessoa[i - 1];
                pessoa[i - 1] = temp;
            }
		
	}
	if (num == 6) {
    char nome[290];
    int a = 0;

    printf("Qual o nome da pessoa a remover?\n");
    gets(nome);
    fflush(stdin);

    for (i = 0; i < n; i++) {
        if (strcmp(nome, pessoa[i].nome) == 0) {
            a = 1;
            for (int j = i; j < n - 1; j++) {
                pessoa[j] = pessoa[j + 1];
            }
            n--;  
            printf("Pessoa removida com sucesso.\n");
            break; 
        }
    }

    if (!a) {
        printf("Pessoa não encontrada.\n");
    }
}

		
}while(num!=7);
}