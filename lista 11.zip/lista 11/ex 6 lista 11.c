#include <stdlib.h>
#include<stdio.h>
#include<ctype.h>
#include<string.h>
typedef struct reg *no;
struct reg {
  int info;
  struct reg *prox;
};
void mostra_LCSE (no lista) {
  if (lista == NULL) {
    printf ("\nLista vazia");
    return;
  }
  no p = lista;
  printf ("\nElementos da lista: ");
  do {
    printf ("%d ",p->info);
    p = p->prox;
  } while (p != lista);
}
void inclui_ord (no *lista, int info) {
  no p = (no) malloc(sizeof(struct reg));
  p->info = info;
  no q=*lista,r;
  if (!*lista) {
    p->prox = p;
    *lista = p;
  }
  else if(q->info>info){
  	p->prox=q;
  	do{
  		q=q->prox;
	  }while(q->prox!=*lista);
	  q->prox=p;
	  *lista=p;
  }
  		
  else {
    do{
    	r=q;
    	q=q->prox;
	}while(q!=*lista && q->info<info);
	r->prox =p;
	p->prox=q;
  }
}

void inverte(no *lista){
	no p=*lista,q,r,s=*lista;
	do{
		q=p->prox;
		p->prox=r;
		r=p;
		p=q;
	}while(p!=s);
	(*lista)->prox=r;
	(*lista)=r;
}

int main () {
  int info,num;
  no lista;    
  char resp;
  lista = NULL;
  printf ("I N S E R C A O\n");
  do {
    printf ("\nDigite um numero inteiro: ");
    scanf ("%d",&info);
    inclui_ord (&lista,info);
    mostra_LCSE (lista);
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
  
  inverte(&lista);
  mostra_LCSE (lista);
}        