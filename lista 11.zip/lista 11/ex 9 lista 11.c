#include <stdlib.h>
#include<stdio.h>
#include<ctype.h>
#include<string.h>
typedef struct reg *no;
struct reg {
  int info;
  struct reg *prox;
};
void mostra_LCSE (no lista) {
  if (lista == NULL) {
    printf ("\nLista vazia");
    return;
  }
  no p = lista;
  printf ("\nElementos da lista: ");
  do {
    printf ("%d ",p->info);
    p = p->prox;
  } while (p != lista);
}
void inclui_ord (no *lista, int info) {
  no p = (no) malloc(sizeof(struct reg));
  p->info = info;
  no q=*lista,r;
  if (!*lista) {
    p->prox = p;
    *lista = p;
  }
  else if(q->info>info){
  	p->prox=q;
  	do{
  		q=q->prox;
	  }while(q->prox!=*lista);
	  q->prox=p;
	  *lista=p;
  }
  		
  else {
    do{
    	r=q;
    	q=q->prox;
	}while(q!=*lista && q->info<info);
	r->prox =p;
	p->prox=q;
  }
}

void copia(no lista, no *lista2){
	no p=lista,s=lista,t=NULL;
	int c=0,a=0,b[1000];
	do{
		a=0;
		no q=lista;
		do{
			if(q->info==p->info)
				a++;
			q=q->prox;			
		}while(q!=lista);
		for(int i=0;i<c;i++){
			if(b[i]==p->info)
				a=0;
		}
		if(a>0){
			b[c]=p->info;
			c++;
			no r = (no)malloc(sizeof(struct reg));
            r->info = p->info;
			if(!*lista2){
				r->prox=r;
				*lista2=r;
		}
		else{
			r->prox=*lista2;
			t->prox=r;
		}
		t=r;
		}
		p=p->prox;
	}while(p!=lista);
}
int main () {
  int info,num;
  no lista,lista2;    
  char resp;
  lista = NULL;
  lista2=NULL;
  printf ("I N S E R C A O\n");
  do {
    printf ("\nDigite um numero inteiro pra lista 1: ");
    scanf ("%d",&info);
    inclui_ord (&lista,info);
    mostra_LCSE (lista);
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
	copia(lista,&lista2);
 	mostra_LCSE(lista2);
}        