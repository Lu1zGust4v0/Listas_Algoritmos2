#include <stdlib.h>
#include<stdio.h>
#include<ctype.h>
#include<string.h>
typedef struct reg *no;
struct reg {
  int info;
  struct reg *prox;
};
void mostra_LCSE (no lista) {
  if (lista == NULL) {
    printf ("\nLista vazia");
    return;
  }
  no p = lista;
  printf ("\nElementos da lista: ");
  do {
    printf ("%d ",p->info);
    p = p->prox;
  } while (p != lista);
}
void inclui_ord (no *lista, int info) {
  no p = (no) malloc(sizeof(struct reg));
  p->info = info;
  no q=*lista,r;
  if (!*lista) {
    p->prox = p;
    *lista = p;
  }
  else if(q->info>info){
  	p->prox=q;
  	do{
  		q=q->prox;
	  }while(q->prox!=*lista);
	  q->prox=p;
	  *lista=p;
  }
  		
  else {
    do{
    	r=q;
    	q=q->prox;
	}while(q!=*lista && q->info<info);
	r->prox =p;
	p->prox=q;
  }
}

void maior(no lista){
	no p=lista;
	no q=lista;
	q=q->prox;
	int b=0,a=0,c[1000],d=0;
	while(p->prox!=lista){
		no q=lista;
		do{
			if(p->info==q->info)
				a++;
			q=q->prox;
	}while(q->prox!=lista);
	if (p->info == q->info)
            a++;
	if(a>b){
		b=a;
		c[0]=p->info;
		d=1;
	}
	else if (a == b) {
            int repetido = 0;
            for (int i = 0; i < d; i++) {
                if (c[i] == p->info) {
                    repetido = 1;
                    break;
                }
            }
            if (!repetido) {
                c[d] = p->info;
                d++;
            }
        }
	a=0;
	p=p->prox;
}
	printf("os que aparecem mais:");
	for(int i=0;i<d;i++)
	printf("%d ",c[i]);
}
void menor(no lista){
	no p=lista;
	no q=lista;
	q=q->prox;
	int b=100000,a=0,c[1000],d=0;
	do{
		no q=lista;
		do{
			if(p->info==q->info)
				a++;
			q=q->prox;
	}while(q->prox!=lista);
	if (p->info == q->info)
            a++;
	if(a<b){
		b=a;
		c[0]=p->info;
		d=1;
	}
	else if (a == b) {
            int repetido = 0;
            for (int i = 0; i < d; i++) {
                if (c[i] == p->info) {
                    repetido = 1;
                    break;
                }
            }
            if (!repetido) {
                c[d] = p->info;
                d++;
            }
        }
	a=0;
	p=p->prox;
}while(p!=lista);
	printf("os que aparecem menos:");
	for(int i=0;i<d;i++)
	printf("%d ",c[i]);
}
int main () {
  int info,num;
  no lista,lista2;    
  char resp;
  lista = NULL;
  lista2=NULL;
  printf ("I N S E R C A O\n");
  do {
    printf ("\nDigite um numero inteiro pra lista 1: ");
    scanf ("%d",&info);
    inclui_ord (&lista,info);
    mostra_LCSE (lista);
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
  maior(lista);
  menor(lista);
 
}        