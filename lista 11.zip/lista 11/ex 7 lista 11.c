#include <stdlib.h>
#include<stdio.h>
#include<ctype.h>
#include<string.h>
typedef struct reg *no;
struct reg {
  int info;
  struct reg *prox;
};
void mostra_LCSE (no lista) {
  if (lista == NULL) {
    printf ("\nLista vazia");
    return;
  }
  no p = lista;
  printf ("\nElementos da lista: ");
  do {
    printf ("%d ",p->info);
    p = p->prox;
  } while (p != lista);
}
void inclui_ord (no *lista, int info) {
  no p = (no) malloc(sizeof(struct reg));
  p->info = info;
  no q=*lista,r;
  if (!*lista) {
    p->prox = p;
    *lista = p;
  }
  else if(q->info>info){
  	p->prox=q;
  	do{
  		q=q->prox;
	  }while(q->prox!=*lista);
	  q->prox=p;
	  *lista=p;
  }
  		
  else {
    do{
    	r=q;
    	q=q->prox;
	}while(q!=*lista && q->info<info);
	r->prox =p;
	p->prox=q;
  }
}

void compara(no lista,no lista2){
	no p =lista,q=lista2;
	int a=0;
	while(p->prox!=lista&&q->prox!=lista2){
		if(p->info!=q->info)	
			return printf("Nao sao iguais");
		p=p->prox;
		q=q->prox;
	}
	return printf("sao iguais");
}

int conta(no lista){
	no p =lista;
	int a=1;
	while(p->prox!=lista){
		a++;
		p=p->prox;
	}
		return a;
}
int main () {
  int info,num;
  no lista,lista2;    
  char resp;
  lista = NULL;
  lista2=NULL;
  printf ("I N S E R C A O\n");
  do {
    printf ("\nDigite um numero inteiro pra lista 1: ");
    scanf ("%d",&info);
    inclui_ord (&lista,info);
    mostra_LCSE (lista);
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
  
   do {
    printf ("\nDigite um numero inteiro pra lista 2: ");
    scanf ("%d",&info);
    inclui_ord (&lista2,info);
    mostra_LCSE (lista2);
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
  int a=conta(lista), b = conta(lista2);
  if(a!=b)
  	printf("nao sao iguais");
	else
		compara(lista, lista2);
}        