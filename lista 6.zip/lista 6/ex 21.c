#include<stdio.h>

int bb (int x, int e, int d, int v[]) {
if (e == d-1)
return d; // base da recursão
else {
int m = (e + d)/2;
if (v[m] < x)
return bb (x, m, d, v);
else
return bb (x, e, m, v);
}
}
int buscabinaria3 (int x, int n, int v[]) {
return bb (x, -1, n, v);
}

int main(){
	int i, v[20],num;
	for(i=0;i<20;i++){
		v[i]=i;
	}
	printf("diga o numero que vc quer procurar no vetor");
	scanf("%d",&num);
	
	printf("posicao %d\n",buscabinaria3(num,20,v));
}