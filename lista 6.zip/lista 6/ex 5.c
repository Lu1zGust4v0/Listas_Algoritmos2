#include<stdio.h>

int buscabinaria(int v[],int a, int b, int c){
	int meio = (b+c)/2;
	if(a==v[meio])
		return meio;
	else if(a<v[meio])
		return buscabinaria(v,a,0,meio-1);
	else
		return buscabinaria(v,a,meio+1,c);
}

int main(){
	int i, v[20],num;
	for(i=0;i<20;i++){
		v[i]=i;
	}
	printf("diga o numero de 0 a 19");
	scanf("%d",&num);
	
	printf("posicao %d\n",buscabinaria(v,num,0,20));
}