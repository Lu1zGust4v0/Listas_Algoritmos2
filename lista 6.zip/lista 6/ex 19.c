#include<stdio.h>

int buscabinaria(int v[],int a, int b, int c){
int m, e = -1, d = a-1;
int x=c;
while (e < d) {
m = (e + d + 1)/2;
if (v[m] < x) e = m;
else d = m-1;
}
return d+1;
}
int main(){
	int i, v[20],num;
	for(i=0;i<20;i++){
		v[i]=i;
	}
	printf("diga o numero que vc quer procurar no vetor");
	scanf("%d",&num);
	
	printf("posicao %d\n",buscabinaria(v,num,0,20));
}