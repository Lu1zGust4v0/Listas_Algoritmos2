#include<stdio.h>
#include<string.h>

struct aluno{
    int num;
    char nome[300];
};

int buscabinaria(struct aluno num[],int a,int b,int c){
    if(b>c)
        return -1;
    int meio=(b+c)/2;
    if(num[meio].num==a)
        return meio;
    else if(num[meio].num>a)
        return buscabinaria(num,a,b,meio-1);
    else
        return buscabinaria(num,a,meio+1,c);
}

int main(){
    int i,j,a,b,numAlunos;
    struct aluno alunos[300];

    printf("Quantos alunos voce quer cadastrar? ");
    scanf("%d",&numAlunos);

    for(i=0;i<numAlunos;i++){
        printf("Digite o nome do aluno: ");
        scanf("%s",alunos[i].nome);
        printf("Digite o numero do aluno: ");
        scanf("%d",&alunos[i].num);
    }

    struct aluno temp;
    for(i=0;i<numAlunos-1;i++){
        for(j=i+1;j<numAlunos;j++){
            if(alunos[i].num>alunos[j].num){
                temp=alunos[i];
                alunos[i]=alunos[j];
                alunos[j]=temp;
            }
        }
    }

    printf("\nQual o numero do aluno que voce quer saber o nome? ");
    scanf("%d",&a);

    b=buscabinaria(alunos,a,0,numAlunos-1);

    if(b==-1){
        printf("Aluno nao encontrado.\n");
    } else {
        printf("O aluno com numero %d e: %s\n",a,alunos[b].nome);
    }

    return 0;
}
