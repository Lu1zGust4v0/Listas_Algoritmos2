#include<stdio.h>

int buscabinaria(int v[],int a, int b, int c){
	int meio = (b+c)/2;
	if(b>c){
		printf("nao existe,");
		return -1;
	}
	
	if(a==v[meio])
		return meio;
	else if(a<v[meio])
		return buscabinaria(v,a,b,meio-1);
	else
		return buscabinaria(v,a,meio+1,c);
}

int main(){
	int i, v[200],num, a,j, aux;
	printf("quantos elementos tem o vetor?\n");
	scanf("%d",&a);
	printf("digite-os");
	for(i=0;i<a;i++)
		scanf("%d",&v[i]);
	for(i=0;i<a;i++){
		for(j=i+1;j<a;j++){
			if(v[i]>v[j])
				aux = v[i];
				v[i]=v[j];
				v[j]=aux;
		}
	}
	
	printf("diga o numero que vc quer procurar no vetor");
	scanf("%d",&num);
	
	printf("posicao %d\n",buscabinaria(v,num,0,a-1));
}