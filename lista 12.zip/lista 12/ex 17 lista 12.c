#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include<ctype.h>
typedef struct reg *no;
struct reg {
           int info;
           struct reg *prox;
};

typedef struct {
   	no prim, ult;
   	int qte;
 } Descritor;
 
void cria_LLSECD (Descritor *lista) {
  (*lista).prim = (*lista).ult = NULL;
  (*lista).qte = 0;
} 
void mostra_LLSECD (Descritor lista) {
  if (lista.qte == 0) {
    printf ("\nLista vazia");
    return;
  }
  no p = lista.prim;
  printf ("\nElementos da lista: ");
  do {
    printf ("%d ",p->info);
    p = p->prox;
  } while (p != NULL);
  printf ("\nTotal de elementos: %d\n",lista.qte);
}
void insere_inicio_LLSECD (Descritor *lista, int info) {
  no p = (no)malloc(sizeof(struct reg));
  p->info=info;
  p->prox=(*lista).prim;
  (*lista).prim=p;
  if((*lista).qte==0)
  	(*lista).ult=p;	
	(*lista).qte++;
}

void inverte(Descritor *lista){
	no p =(*lista).prim->prox->prox,r =(*lista).prim->prox,q=(*lista).prim;
	
	while(p){
		r->prox=q;
		q=r;
		r=p;
		p=p->prox;	
	}
	r->prox=q;
	(*lista).ult=(*lista).prim;
	(*lista).prim=r;
	(*lista).ult->prox=NULL;
		
		
}


int main () {
  int a,info;
  Descritor lista;    
  char resp;
  cria_LLSECD (&lista);
  printf ("I N S E R C A O\n");
  do {
    printf ("\nDigite um numero inteiro: ");
    scanf ("%d",&info);
    insere_inicio_LLSECD (&lista,info);
    mostra_LLSECD (lista);
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
	inverte(&lista);
	mostra_LLSECD (lista);
}        