#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include<ctype.h>
typedef struct reg *no;
struct reg {
           int info;
           struct reg *prox;
};

typedef struct {
   	no prim, ult;
   	int qte;
 } Descritor;
 
void cria_LLSECD (Descritor *lista) {
  (*lista).prim = (*lista).ult = NULL;
  (*lista).qte = 0;
} 
void mostra_LLSECD (Descritor lista) {
  if (lista.qte == 0) {
    printf ("\nLista vazia");
    return;
  }
  no p = lista.prim;
  printf ("\nElementos da lista: ");
  do {
    printf ("%d ",p->info);
    p = p->prox;
  } while (p != NULL);
  printf ("\nTotal de elementos: %d\n",lista.qte);
}
void insere_inicio_LLSECD (Descritor *lista, int info) {
  no p = (no)malloc(sizeof(struct reg));
  p->info=info;
  p->prox=(*lista).prim;
  (*lista).prim=p;
  if((*lista).qte==0)
  	(*lista).ult=p;	
	(*lista).qte++;
}

void removee(Descritor *lista, int info){
	int a=1;
	no p=(*lista).prim,q;
	if(info<1 || info>(*lista).qte)
		return;
	if(info==1){
		(*lista).prim=p->prox;
		free(p);
		return;
	}
	while(a<info){
		a++;
		q=p;
		p=p->prox;
	}
	if(p->prox==NULL)
		(*lista).ult=q;
	q->prox=p->prox;
	free(p);
	(*lista).qte--;
}


int main () {
  int a,info;
  Descritor lista;    
  char resp;
  cria_LLSECD (&lista);
  printf ("I N S E R C A O\n");
  do {
    printf ("\nDigite um numero inteiro: ");
    scanf ("%d",&info);
    insere_inicio_LLSECD (&lista,info);
    mostra_LLSECD (lista);
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
  printf("qual posicao que vc quer remover?");
  scanf("%d",&info);
	removee(&lista, info);
	mostra_LLSECD (lista);
}        