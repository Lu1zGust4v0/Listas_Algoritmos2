#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include<ctype.h>
typedef struct reg *no;
struct reg {
           int info;
           struct reg *prox;
};

typedef struct {
   	no prim, ult;
   	int qte;
 } Descritor;
 
void cria_LLSECD (Descritor *lista) {
  (*lista).prim = (*lista).ult = NULL;
  (*lista).qte = 0;
} 
void mostra_LLSECD (Descritor lista) {
  if (lista.qte == 0) {
    printf ("\nLista vazia");
    return;
  }
  no p = lista.prim;
  printf ("\nElementos da lista: ");
  do {
    printf ("%d ",p->info);
    p = p->prox;
  } while (p != NULL);
}
void insere_inicio_LLSECD (Descritor *lista, int info) {
  no p = (no)malloc(sizeof(struct reg));
  p->info=info;
  p->prox=(*lista).prim;
  (*lista).prim=p;
  if((*lista).qte==0)
  	(*lista).ult=p;	
	(*lista).qte++;
}

void copia(Descritor lista, Descritor*lista2){
	int v[1000],a=0,i=0,j;
	no p=lista.prim;
	no q = (no)malloc(sizeof(struct reg));
	q->info=p->info;
	v[i++]=q->info;
  (*lista2).prim=q;
  	(*lista2).ult=q;
  	(*lista2).qte=1;
	p=p->prox;
	q->prox=NULL;
	while(p){
		a=0;
		q = (no)malloc(sizeof(struct reg));
		q->info=p->info;
		for(j=0;j<i;j++){
			if(v[j]==q->info)
				a=1;	
		}
		if(!a){
		v[i++]=q->info;
		q->prox=NULL;
		(*lista2).ult->prox=q;
		(*lista2).ult=q;
		(*lista2).qte++;
	}
		p=p->prox;
	}
}


int main () {
  int a,info;
  Descritor lista,lista2;
  char resp;
  cria_LLSECD (&lista);
   cria_LLSECD (&lista2);
  printf ("I N S E R C A O\n");
  do {
    printf ("\nDigite um numero inteiro: ");
    scanf ("%d",&info);
    insere_inicio_LLSECD (&lista,info);
    mostra_LLSECD (lista);
    printf ("\n\nContinua (S/N)? ");   
    do {
      resp = toupper(getchar());
    } while (resp!='N' && resp!='S');
  } while (resp!='N');
	copia(lista,&lista2);
	mostra_LLSECD (lista2);
	
}        